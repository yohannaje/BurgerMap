# Generating CartoCSS docs

From the `docs-generator/` directory:

```
$ npm install
```

Then:

```
$ node generate.js
```

Will save docs to `docs/`.